//Apply do while loop to calculat factorial of a number such that, program asks user, if he wants to continue, if yes, program should run again

public class Object_Cont;

public static void main(String[] args) {
    Scanner scanner = new Scanner(System.in);
    // Greetings
    System.out.println("Welcome to my factorial program! ");
    System.out.println("Please choose from the following: ");

    //Menu
    System.out.println("1. Run Program");
    System.out.println("2. Exit Program");

    int choice = scanner.nextInt();

    switch (choice) {
        case 1:
            System.out.println("This program will determine the factorial value of positive integers.");
            do {
                System.out.println("The starting number is 1.");
                System.out.println("Please enter an ending integer value:");
                int n = scanner.nextInt();
                for (int i = 1; i <= n; i++) {
                    System.out.println(i + "! = " + fact(i));//call to function
                }
                System.out.println("Run factorial program again? (Y for Yes, N for No): ");
                String Cont = scanner.next();
                if (Cont.equals("N")) {
                    break;
                }
            } while (Cont.equals("Y"));// do while loop
            break;
        //Menu Exit
        case 2:
            System.out.println("Thank you for using the program.");
            System.out.println("Goodbye");
        default:
            System.exit(1); // remebered from last week to set this to one
            System.out.println("Goodbye");
            break;
    }
}//Factorial Math

static long fact(int x) {
    long f = 1;
    for (int i = 1; i <= x; i++) {
        f = f * i;
    }
    return f;
} //End Main Method