//WAP to creat a fuction that check if no. is odd or even. call this function from main method


package SimpleNumberPrograms;

public class EvenOrOdd {
	int x;
	
	public void evenOrOdd() {
		if (x % 2 == 0) {
			System.out.println("\n First Method: You have entered EVEN Number");
		}
		else {
			System.out.println("\n First Method: You have entered ODD Number");
		}
	}	
	public int evenOrOddAgain(int Number) {
		if (Number % 2 == 0) {
			return 1;
		}
		else {
			return 0;
		}
	}
}