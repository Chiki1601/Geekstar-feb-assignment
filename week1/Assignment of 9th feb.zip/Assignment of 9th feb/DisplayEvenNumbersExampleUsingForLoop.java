//Write a java program to print 2,4,6,8,10 using for loop 

public class DisplayEvenNumbersExampleUsingForLoop  
{  
public static void main(String args[])   
{  
int number=10;  
System.out.print("List of even numbers from 1 to "+number+": ");  
for (int i=1; i<=number; i++)   
{  
//logic to check if the number is even or not  
//if i%2 is equal to zero, the number is even  
if (i%2==0)   
{  
System.out.print(i + " ");  
}  
}  
}  
}  