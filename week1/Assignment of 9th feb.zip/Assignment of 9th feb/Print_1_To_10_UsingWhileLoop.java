//Write a java program to print 1 to 10 using while loop

package IncludeHelp;

public class Print_1_To_10_UsingWhileLoop 
{
	public static void main(String args[])
	{
		//loop counter initialisation
		int i=1;

		//print statement
		System.out.println("Output is : ");

		//loop to print 1 to 10.
		while(i<=10)	
		{
			System.out.println(i);
			i++;
		}
	}
}

