//Write a java  program to print 10 to 1 using while loop

package IncludeHelp;

public class Print_10_To_1_UsingWhileLoop
{
	public static void main(String args[])
	{
		//loop counter initialisation
		int i=10;

		//print statement
		System.out.println("Output is : ");

		//loop to print 10 to 1.
		while(i>=10)	
		{
			System.out.println(i);
			i--;
		}
	}
}